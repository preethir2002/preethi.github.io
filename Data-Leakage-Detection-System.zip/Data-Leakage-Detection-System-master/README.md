# Semester Final Project
A Data Leakage Detection system to detect Leckage of data inside an organization, and help in finding the source of leakage if one occures.


# Language Used:
- Java,
- Javascript,
- CSS.

# Server 
- Apache Tomcat

