package uploader;


public class path {

	public path(){
		
	}
	public static String path = "D:\\2017-18\\workspace_17-18\\Dataleakage_all_works\\Dataleakage\\userdata\\";
	public static String leakpath = "D:\\2017-18\\workspace_17-18\\Dataleakage_all_works\\Dataleakage\\leakpath\\";
}
