package sendmail;

public class main {

	
	public static void main(String args[]) {
		SimpleSendEmail emails = new SimpleSendEmail("shaileshbhokare1995@gmail.com","File Report ", " sucessfully uploaded decryption key is ");
		
	}
	
}
